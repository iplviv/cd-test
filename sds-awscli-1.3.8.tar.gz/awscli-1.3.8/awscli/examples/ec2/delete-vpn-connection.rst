**To delete a VPN connection**

This example deletes the specified VPN connection.

Command::

  aws ec2 delete-vpn-connection --vpn-connection-id vpn-40f41529

Output::

  {
      "return": "true"
  }