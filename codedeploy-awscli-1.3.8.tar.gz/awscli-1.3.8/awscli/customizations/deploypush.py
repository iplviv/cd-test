# Copyright 2014 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

import logging
import re
import os
import zipfile
import tempfile
import io
import contextlib

from datetime import datetime
from awscli.customizations.commands import BasicCommand
from awscli.customizations.service import Service
from awscli.arguments import CustomArgument
from botocore.vendored import requests


LOG = logging.getLogger(__name__)

ONE_MB = 1 << 20
MULTIPART_LIMIT = 6 * ONE_MB
IGNORE_HIDDEN_FILES_DOC_STR = ('Optional. Set this flag to not bundle and upload hidden files'
                               ' to Amazon S3; otherwise, false (the default).')
NO_IGNORE_HIDDEN_FILES_DOC_STR = ('Optional. Set this flag to bundle and upload hidden files'
                                  ' to Amazon S3 (the default); otherwise true.')

def initialize(cli):
    """
    The entry point for CodeDeploy high level commands.
    """
    cli.register('building-command-table.deploy', inject_commands)


def inject_commands(command_table, session, **kwargs):
    """
    Commands Push
    """
    command_table['push'] = DeployPush(session)


@contextlib.contextmanager
def compress(src, ignore_hidden_files=False):
    abs_src_path = os.path.abspath(src)
    app_specs_path = os.path.sep.join([abs_src_path, 'appspec.yml'])
    with tempfile.TemporaryFile() as f:
        with zipfile.ZipFile(f, 'w') as z:
            contains_appspecs = False
            for root, dirs, files in os.walk(src, topdown=True):
                if ignore_hidden_files:
                    files = [fn for fn in files if not fn.startswith('.')]
                    dirs[:] = [d for d in dirs if not d.startswith('.')]
                for fname in files:
                    path = os.path.join(root, fname)
                    path = os.path.abspath(path)
                    arc_name = path[len(abs_src_path)+1:]
                    if path == app_specs_path:
                        contains_appspecs = True
                    z.write(path, arc_name)
            if contains_appspecs is False:
                raise RuntimeError(app_specs_path + ' was not found')
        yield f

class DeployBase(BasicCommand):
    """
    DeployBase Class that handles compression and upload
    """
    
    @property
    def arg_table(self):
        current_arg_table = BasicCommand.arg_table.fget(self)
        arg = CustomArgument(
            name='ignore-hidden-files',
            help_text=IGNORE_HIDDEN_FILES_DOC_STR,
            action='store_true')
        current_arg_table[arg.name] = arg
        arg = CustomArgument(
            name='no-ignore-hidden-files',
            help_text=NO_IGNORE_HIDDEN_FILES_DOC_STR,
            action='store_false')
        current_arg_table[arg.name] = arg
        return current_arg_table

    def _run_main(self, args, parsed_globals):
        self.s3 = Service('s3', session=self._session)
        self.deploy = Service('deploy', session=self._session,
                           endpoint_args={'verify': parsed_globals.verify_ssl})
        self._call(args, parsed_globals)

    def _flatten_opts(self, opts, parsed_globals):
        matcher = re.match(r's3://(.+?)/(.+)', opts.s3_location)
        try:
            opts.bucket = matcher.group(1)
            opts.key = matcher.group(2)
        except Exception as e:
            raise RuntimeError("--s3-location must specify the Amazon S3 URL format as s3://<bucket>/<key>")
        if opts.source:
            self.source = opts.source
        else:
            self.source = '.'
        if not opts.no_ignore_hidden_files and opts.ignore_hidden_files:
            raise RuntimeError("You cannot specify both --ignore-hidden-files and --no-ignore-hidden-files.")

    def _call(self, opts, parsed_globals):
        self._flatten_opts(opts, globals)
        with compress(self.source, opts.ignore_hidden_files) as bundle:
            self.upload_response = self._upload_to_s3(
                opts.bucket, opts.key, bundle)
            self._register_revision(opts)

    def _register_revision(self, opts):
        description = opts.description
        if description is None:
            description = ('Uploaded by AWS CLI ' +
                           '%s UTC' % datetime.utcnow().isoformat())
        self.deploy.RegisterApplicationRevision(
            applicationName=opts.application_name,
            revision=self._get_s3_location(opts),
            description=description)

    def _upload_to_s3(self, bucket_name, key_name, bundle):
        bundle.seek(0, 2)
        size_remaining = bundle.tell()
        bundle.seek(0)

        if size_remaining < MULTIPART_LIMIT:
            return self.s3.PutObject(
                bucket=bucket_name,
                key=key_name,
                body=bundle)
        else:
            return self._multipart_upload_to_s3(
                bucket_name, key_name, bundle, size_remaining)

    def _multipart_upload_to_s3(self, bucket_name, key_name, bundle, size):
        upload = self.s3.CreateMultipartUpload(
            bucket=bucket_name,
            key=key_name)
        upload_id = upload['UploadId']
        try:
            part_num = 1
            multipart_list = []
            bundle.seek(0)
            while size > 0:
                data = bundle.read(MULTIPART_LIMIT)
                upload_part = self.s3.UploadPart(
                    bucket=bucket_name,
                    key=key_name,
                    uploadId=upload_id,
                    partNumber=part_num,
                    body=io.BytesIO(data))

                multipart_list.append(
                    {'PartNumber': part_num,
                     'ETag': upload_part['ETag']})

                part_num += 1
                size -= len(data)
            return self.s3.CompleteMultipartUpload(
                bucket=bucket_name,
                key=key_name,
                uploadId=upload_id,
                multipartUpload={'Parts': multipart_list})
        except Exception as e:
            self.s3.AbortMultipartUpload(
                bucket=bucket_name,
                key=key_name,
                uploadId=upload_id)
            raise(e)

    def _get_s3_location(self, opts):
        s3_location = {
            'bucket': opts.bucket,
            'key': opts.key,
            'bundleType': 'zip',
            'eTag': self.upload_response['ETag']
            }
        if 'VersionId' in self.upload_response:
            s3_location['version'] = self.upload_response['VersionId']
        return s3_location


class DeployPush(DeployBase):
    """
    Compresses the given directory into archive, and pushes it
    to the specified location in S3 where CodeDeploy would deploy.
    """
    NAME = 'push'
    DESCRIPTION = ('Bundles and uploads to Amazon Simple Storage Service'
                   ' (Amazon S3) an application revision, which is an archive'
                   ' file that contains deployable content and an'
                   ' accompanying Application Specification file (AppSpec file'
                   ' ). If the upload is successful, a message is returned'
                   ' that describes how to call the create-deployment command'
                   ' to deploy the application revision from Amazon S3 to target'
                   ' Amazon Elastic Compute Cloud (Amazon EC2) instances.')

    SYNOPSIS = ('aws deploy push'
                ' --application-name app-name'
                ' --s3-location s3://bucket/key'
                ' [--ignore-hidden-files | --no-ignore-hidden-files]'
                ' [--source .]'
                ' [--description "Uploaded by AWS CLI \'time\' UTC"]')

    ARG_TABLE = [
        {'name': 'application-name',
         'required': True,
         'help_text': ('Required. The name of the AWS CodeDeploy'
                       ' application to be associated'
                       ' with the application revision.')},
        {'name': 's3-location',
         'required': True,
         'help_text': ('Required. Information about the location of the'
                       ' application revision to be uploaded to Amazon S3. You'
                       ' must specify both a bucket and a key that'
                       ' represent the Amazon S3 bucket name and the'
                       ' object key name. Use the format s3://\<bucket\>/\<key\>')},
        {'name': 'source',
         'help_text': ('Optional. The location of the deployable content and'
                       ' the accompanying AppSpec file on the development '
                       ' machine to be bundled and uploaded to Amazon S3.'
                       ' If not specified, the current directory is used.')},
        {'name': 'description',
         'help_text': ('Optional. A comment that summarizes the application revision.'
                       ' If not specified, the default string "Uploaded by'
                       ' AWS CLI \'time\' UTC" is used, where \'time\' is the '
                       ' current system time in Coordinated Universal Time'
                       '(UTC).')}
        ]

    def _call(self, opts, globals):
        DeployBase._call(self, opts, globals)
        s3location_string = (' --revision '
                             'bucket=' + opts.bucket +
                             ',key=' + opts.key +
                             ',bundleType=zip' +
                             ',eTag=' + self.upload_response['ETag'])
        if 'VersionId' in self.upload_response:
            s3location_string += (',version=' +
                                  self.upload_response['VersionId'])
        output = ('To deploy with this revision, run: \n' +
                  'aws deploy create-deployment' +
                  ' --application-name ' + opts.application_name +
                  s3location_string +
                  ' --deployment-group-name <deployment-group-name>' +
                  ' --deployment-config-name <deployment-config-name>' +
                  ' --description <description>')
        print(output)
