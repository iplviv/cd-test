**To detach a network interface from your instance**

This example detaches the specified network interface from the specified instance.

Command::

  aws ec2 detach-network-interface --attachment-id eni-attach-66c4350a

Output::

  {
      "return": "true"
  }